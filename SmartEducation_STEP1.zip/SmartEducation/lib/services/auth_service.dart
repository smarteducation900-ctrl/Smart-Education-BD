import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;

  Future<User?> register({
    required String name, required String email, required String password,
    required String role, required String dateOfBirth, required String gender,
    required String className, required String institution, required String district,
    required String division, required String academicYear,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
      final user = credential.user;
      if (user == null) throw Exception('Account could not be created.');
      await user.updateDisplayName(name.trim());
      await _firestore.collection('users').doc(user.uid).set({
        'uid': user.uid, 'name': name.trim(), 'email': email.trim(), 'role': role,
        'dateOfBirth': dateOfBirth, 'gender': gender, 'className': className,
        'institution': institution, 'district': district, 'division': division,
        'academicYear': academicYear, 'profilePhoto': '', 'coverPhoto': '', 'bio': '',
        'followersCount': 0, 'followingCount': 0, 'postsCount': 0, 'reelsCount': 0,
        'createdAt': FieldValue.serverTimestamp(), 'isOnline': true,
      });
      return user;
    } on FirebaseAuthException catch (e) {
      throw Exception(_authErrorMessage(e.code));
    }
  }

  Future<User?> login({required String email, required String password}) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
      return credential.user;
    } on FirebaseAuthException catch (e) {
      throw Exception(_authErrorMessage(e.code));
    }
  }

  Future<void> logout() async {
    final user = _auth.currentUser;
    if (user != null) {
      try {
        await _firestore.collection('users').doc(user.uid).update({'isOnline': false, 'lastSeen': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
    await _auth.signOut();
  }

  String _authErrorMessage(String code) {
    switch (code) {
      case 'invalid-email': return 'Email address is not valid.';
      case 'user-not-found': return 'No account found with this email.';
      case 'wrong-password':
      case 'invalid-credential': return 'Email or password is incorrect.';
      case 'email-already-in-use': return 'This email is already registered.';
      case 'weak-password': return 'Password must contain at least 6 characters.';
      case 'network-request-failed': return 'Please check your internet connection.';
      case 'too-many-requests': return 'Too many attempts. Please try again later.';
      default: return 'Something went wrong. Please try again.';
    }
  }
}
