import 'package:flutter/material.dart';

class AppButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final IconData? icon;

  const AppButton({super.key, required this.text, required this.onPressed, this.icon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: icon == null
          ? ElevatedButton(onPressed: onPressed, child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)))
          : ElevatedButton.icon(onPressed: onPressed, icon: Icon(icon), label: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
    );
  }
}
