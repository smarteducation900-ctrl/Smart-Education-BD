import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import 'home_screen.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget { const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen>{
  @override void initState(){super.initState();Timer(const Duration(seconds:2),_openNext);}
  void _openNext(){if(!mounted)return;final user=FirebaseAuth.instance.currentUser;Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>user==null?const WelcomeScreen():const HomeScreen()));}
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:AppTheme.primary,body:SafeArea(child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:125,height:125,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(35)),child:const Icon(Icons.school_rounded,size:75,color:AppTheme.primary)),const SizedBox(height:28),const Text('Smart Education',style:TextStyle(color:Colors.white,fontSize:30,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Text('Learn • Share • Grow',style:TextStyle(color:Colors.white70,fontSize:16)),const SizedBox(height:45),const SizedBox(width:25,height:25,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2.5)),const SizedBox(height:12),const Text('Loading...',style:TextStyle(color:Colors.white70))]))));
}
