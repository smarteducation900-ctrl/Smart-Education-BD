class UserModel {
  final String uid;
  final String name;
  final String email;
  final String role;
  final String dateOfBirth;
  final String gender;
  final String className;
  final String institution;
  final String district;
  final String division;
  final String academicYear;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    required this.dateOfBirth,
    required this.gender,
    required this.className,
    required this.institution,
    required this.district,
    required this.division,
    required this.academicYear,
  });

  Map<String, dynamic> toMap() => {
    'uid': uid, 'name': name, 'email': email, 'role': role,
    'dateOfBirth': dateOfBirth, 'gender': gender, 'className': className,
    'institution': institution, 'district': district, 'division': division,
    'academicYear': academicYear,
  };

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
    uid: map['uid'] ?? '', name: map['name'] ?? '', email: map['email'] ?? '',
    role: map['role'] ?? 'student', dateOfBirth: map['dateOfBirth'] ?? '',
    gender: map['gender'] ?? '', className: map['className'] ?? '',
    institution: map['institution'] ?? '', district: map['district'] ?? '',
    division: map['division'] ?? '', academicYear: map['academicYear'] ?? '',
  );
}
