# Smart Education — STEP 1

Flutter source project for the Smart Education educational social platform.

## Included
- Modern blue/white UI
- Splash screen
- Welcome screen
- Login
- Registration
- Student/Teacher selection
- DOB, gender, class, institution, district, division, academic year
- Firebase Authentication integration
- Firestore user profile integration
- Home dashboard
- Bottom navigation
- Profile placeholder
- Reels/Messages/Create placeholders
- Light/dark theme support

## Firebase setup
1. Install Flutter and verify with `flutter doctor`.
2. Run `flutter pub get`.
3. Run `dart pub global activate flutterfire_cli`.
4. Run `flutterfire configure` and select your Firebase project.
5. In Firebase Console enable Authentication > Email/Password.
6. Create Firestore Database.
7. For Android, download `google-services.json` from Firebase and place it at `android/app/google-services.json` if your Android project is already generated/configured.

## Generate Android platform files
This ZIP keeps the platform folder minimal so it can be regenerated for your installed Flutter version. From the project root run:

`flutter create .`

Then run:

`flutter pub get`

`flutter run`

Do not delete the `lib` folder or `pubspec.yaml` when running `flutter create .`.

## Important
The Reels, Messenger, Feed, Notifications and real Online Class systems are intentionally not implemented in STEP 1. They will be added in later steps.
